import { 
  users, type User, type InsertUser,
  moodEntries, type MoodEntry, type InsertMoodEntry
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getMoodEntries(): Promise<MoodEntry[]>;
  getMoodEntry(id: string): Promise<MoodEntry | undefined>;
  createMoodEntry(entry: InsertMoodEntry): Promise<MoodEntry>;
  deleteMoodEntry(id: string): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getMoodEntries(): Promise<MoodEntry[]> {
    const entries = await db
      .select()
      .from(moodEntries)
      .orderBy(desc(moodEntries.createdAt))
      .limit(50);
    return entries;
  }

  async getMoodEntry(id: string): Promise<MoodEntry | undefined> {
    const [entry] = await db.select().from(moodEntries).where(eq(moodEntries.id, id));
    return entry || undefined;
  }

  async createMoodEntry(entry: InsertMoodEntry): Promise<MoodEntry> {
    const [moodEntry] = await db
      .insert(moodEntries)
      .values(entry)
      .returning();
    return moodEntry;
  }

  async deleteMoodEntry(id: string): Promise<boolean> {
    const result = await db.delete(moodEntries).where(eq(moodEntries.id, id)).returning();
    return result.length > 0;
  }
}

export const storage = new DatabaseStorage();
