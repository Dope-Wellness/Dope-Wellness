import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMoodEntrySchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.get("/api/mood-entries", async (req, res) => {
    try {
      const entries = await storage.getMoodEntries();
      res.json(entries);
    } catch (error) {
      console.error("Error fetching mood entries:", error);
      res.status(500).json({ error: "Failed to fetch mood entries" });
    }
  });

  app.get("/api/mood-entries/:id", async (req, res) => {
    try {
      const entry = await storage.getMoodEntry(req.params.id);
      if (!entry) {
        return res.status(404).json({ error: "Mood entry not found" });
      }
      res.json(entry);
    } catch (error) {
      console.error("Error fetching mood entry:", error);
      res.status(500).json({ error: "Failed to fetch mood entry" });
    }
  });

  app.post("/api/mood-entries", async (req, res) => {
    try {
      const validatedData = insertMoodEntrySchema.parse(req.body);
      const entry = await storage.createMoodEntry(validatedData);
      res.status(201).json(entry);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid mood entry data", details: error.errors });
      }
      console.error("Error creating mood entry:", error);
      res.status(500).json({ error: "Failed to create mood entry" });
    }
  });

  app.delete("/api/mood-entries/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteMoodEntry(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "Mood entry not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting mood entry:", error);
      res.status(500).json({ error: "Failed to delete mood entry" });
    }
  });

  return httpServer;
}
