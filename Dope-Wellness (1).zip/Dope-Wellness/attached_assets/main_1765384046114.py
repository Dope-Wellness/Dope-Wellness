import os
import threading
import time
import random
import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import pygame
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt

# ============================================================
#  Pastel Blue Colour Palette 🎨
# ============================================================
COL_BG = "#e3f2fd"         # baby blue
COL_PANEL = "#bbdefb"      # soft blue
COL_BOX = "#d7e3fc"        # lighter blue
COL_BTN = "#90caf9"        # sky blue
COL_BTN_HOVER = "#64b5f6"
COL_TEXT = "#1a334a"       # navy-grey
COL_DOPA_HIGH = "#4ba3c7"  # teal blue

APP_NAME = "BlueAura Therapy"

# ============================================================
#  DATABASE SETUP (SQLite)
# ============================================================
DB_FILE = "songs.db"
SUPPORTED_LANGUAGES = ["Any", "English", "Hindi", "Tamil", "Telugu", "Kannada"]

def init_database():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS songs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            filepath TEXT,
            mood TEXT,
            language TEXT DEFAULT 'Any'
        )
    """)
    c.execute("PRAGMA table_info(songs)")
    cols = [r[1] for r in c.fetchall()]
    if "language" not in cols:
        try:
            c.execute("ALTER TABLE songs ADD COLUMN language TEXT DEFAULT 'Any'")
        except Exception:
            pass
    conn.commit()
    conn.close()

def add_song_to_db(title, filepath, mood, language):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("INSERT INTO songs (title, filepath, mood, language) VALUES (?, ?, ?, ?)",
              (title, filepath, mood, language))
    conn.commit()
    conn.close()

def get_songs_for_mood_and_language(mood, language):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    rows = []
    if language and language != "Any":
        c.execute("SELECT filepath FROM songs WHERE mood=? AND language=?", (mood, language))
        rows = c.fetchall()
    if not rows:
        c.execute("SELECT filepath FROM songs WHERE mood=?", (mood,))
        rows = c.fetchall()
    conn.close()
    return [r[0] for r in rows]

# ============================================================
#  Music thread
# ============================================================
class MusicPlayer(threading.Thread):
    def __init__(self):
        super().__init__(daemon=True)
        try:
            pygame.mixer.init()
        except Exception as e:
            print("Audio init error:", e)
        self.playlist = []
        self.idx = 0
        self.playing = False
        self._stop = threading.Event()

    def set_playlist(self, files):
        self.playlist = [f for f in files if os.path.exists(f)]
        self.idx = 0

    def run(self):
        while not self._stop.is_set():
            if self.playlist and self.playing:
                if not pygame.mixer.music.get_busy():
                    fn = self.playlist[self.idx % len(self.playlist)]
                    try:
                        pygame.mixer.music.load(fn)
                        pygame.mixer.music.play()
                    except Exception as e:
                        print("Play error:", e)
                    self.idx += 1
            time.sleep(0.3)

    def start_playing(self):
        self.playing = True

    def stop(self):
        self._stop.set()
        try:
            pygame.mixer.music.stop()
        except Exception:
            pass

# ============================================================
#  QUESTIONS, MOODS, AND DOPAMINE SIM
# ============================================================
QUESTIONS = [
    "I feel stressed or on-edge.",
    "I feel calm and relaxed.",
    "I have energy and motivation.",
    "I feel sad or low.",
    "I can concentrate easily.",
]

MOODS = ["Very Sad", "Anxious", "Neutral", "Calm", "Energetic", "Focused"]
MOOD_EFFECT = {
    "Very Sad": -0.40,
    "Anxious": -0.22,
    "Neutral": +0.03,
    "Calm": +0.15,
    "Energetic": +0.40,
    "Focused": +0.25,
}

BASE_DOPAMINE = 50.0
TIME_STEP = 0.5
MAX_POINTS = 300

# ============================================================
#  BLUEAURA APP CLASS
# ============================================================
class BlueAuraApp:
    def __init__(self, root):
        self.root = root
        root.title(APP_NAME)
        root.geometry("1100x680")
        root.configure(bg=COL_BG)
        init_database()

        self.music = MusicPlayer()
        self.music.start()

        # ------------------
        # LEFT PANEL
        # ------------------
        left = tk.Frame(root, bg=COL_PANEL, width=360)
        left.pack(side=tk.LEFT, fill=tk.Y)

        tk.Label(left, text="BlueAura Therapy", font=("Segoe UI", 18, "bold"),
                 bg=COL_PANEL, fg=COL_TEXT).pack(pady=10)

        tk.Label(left, text="Choose Language:", bg=COL_PANEL, fg=COL_TEXT,
                 font=("Segoe UI", 12)).pack(pady=(6,0))
        self.lang_var = tk.StringVar(value="Any")
        ttk.OptionMenu(left, self.lang_var, "Any", *SUPPORTED_LANGUAGES).pack(pady=(0,8))

        # Buttons
        self.make_button(left, "Start Questionnaire", self.start_questionnaire).pack(fill=tk.X, padx=12, pady=6)
        self.make_button(left, "Analyze Current Answers & Play", self.analyze_mood_manual).pack(fill=tk.X, padx=12, pady=6)
        self.make_button(left, "Add Songs to Database", self.add_song_dialog).pack(fill=tk.X, padx=12, pady=6)
        self.make_button(left, "Stop Music", self.stop_music).pack(fill=tk.X, padx=12, pady=6)

        self.mood_var = tk.StringVar(value="Mood: —")
        tk.Label(left, textvariable=self.mood_var, bg=COL_PANEL, fg=COL_TEXT,
                 font=("Segoe UI", 14, "bold")).pack(pady=8)

        self.dopa_var = tk.StringVar(value="Dopamine: —")
        tk.Label(left, textvariable=self.dopa_var, bg=COL_PANEL,
                 fg=COL_TEXT, font=("Segoe UI", 12)).pack(pady=4)

        # ------------------
        # MIDDLE PANEL (Glass Box)
        # ------------------
        mid = tk.Frame(root, bg=COL_BG, width=360)
        mid.pack(side=tk.LEFT, fill=tk.Y, padx=6)

        wizard_box = self.make_glass_frame(mid, width=340, height=220)
        wizard_box.pack(padx=10, pady=12, fill=tk.BOTH, expand=False)

        self.question_label = tk.Label(wizard_box, text="Press Start to begin questionnaire",
                                       wraplength=320, justify="left", bg="#ffffff", fg=COL_TEXT,
                                       font=("Segoe UI", 12))
        self.question_label.pack(pady=(6,12))

        self.res_var = tk.IntVar(value=3)
        rb_frame = tk.Frame(wizard_box, bg="#ffffff")
        rb_frame.pack(pady=(4,8))
        self.radio_buttons = []
        for v in range(1, 6):
            r = tk.Radiobutton(rb_frame, text=str(v), variable=self.res_var, value=v,
                               bg="#ffffff", fg=COL_TEXT, selectcolor=COL_BTN,
                               font=("Segoe UI", 10))
            r.pack(side=tk.LEFT, padx=6)
            self.radio_buttons.append(r)

        nav_frame = tk.Frame(wizard_box, bg="#ffffff")
        nav_frame.pack(pady=(8,2))
        self.prev_btn = tk.Button(nav_frame, text="Previous", command=self.prev_question, state=tk.DISABLED,
                                  bg=COL_BTN, fg=COL_TEXT, font=("Segoe UI", 10, "bold"))
        self.prev_btn.pack(side=tk.LEFT, padx=6)
        self.next_btn = tk.Button(nav_frame, text="Next", command=self.next_question,
                                  bg=COL_BTN, fg=COL_TEXT, font=("Segoe UI", 10, "bold"))
        self.next_btn.pack(side=tk.LEFT, padx=6)

        self.progress_label = tk.Label(wizard_box, text="Question 0/0", bg="#ffffff", fg=COL_TEXT,
                                       font=("Segoe UI", 10))
        self.progress_label.pack(pady=(8,0))

        # internal state
        self.q_index = -1
        self.responses = [3] * len(QUESTIONS)

        # ------------------
        # RIGHT PANEL - Graph
        # ------------------
        right = tk.Frame(root, bg=COL_BG)
        right.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        self.fig, self.ax = plt.subplots(figsize=(7, 4))
        self.ax.set_facecolor("#f7fbff")
        self.line, = self.ax.plot([], [], lw=3, color=COL_DOPA_HIGH)
        self.ax.grid(True, color="#cfe0f5")
        self.ax.set_xlabel("Time (s)")
        self.ax.set_ylabel("Dopamine")

        self.canvas = FigureCanvasTkAgg(self.fig, master=right)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        # Sim variables
        self.current_mood = "Neutral"
        self.sim_running = False
        self.dopa_vals = []
        self.time_vals = []
        self.cur_time = 0
        self.cur_dopa = BASE_DOPAMINE

    # -----------------------------------
    # Glass Frame Helper
    # -----------------------------------
    def make_glass_frame(self, parent, width=None, height=None):
        frame = tk.Frame(parent, bg="#ffffff", bd=0)
        frame.pack_propagate(False)
        if width: frame.config(width=width)
        if height: frame.config(height=height)
        return frame

    # -----------------------------------
    # UI Button Maker
    # -----------------------------------
    def make_button(self, parent, text, cmd):
        b = tk.Button(parent, text=text, command=cmd, bg=COL_BTN, fg=COL_TEXT,
                      activebackground=COL_BTN_HOVER, relief="ridge",
                      font=("Segoe UI", 12, "bold"), bd=3)
        return b

    # -----------------------------------
    # Questionnaire logic
    # -----------------------------------
    def start_questionnaire(self):
        self.q_index = 0
        self.responses = [3] * len(QUESTIONS)
        self.show_question(0)

    def show_question(self, idx):
        if idx < 0 or idx >= len(QUESTIONS): return
        self.q_index = idx
        self.question_label.config(text=f"{idx+1}. {QUESTIONS[idx]}")
        self.res_var.set(self.responses[idx])
        self.progress_label.config(text=f"Question {idx+1}/{len(QUESTIONS)}")
        self.prev_btn.config(state=tk.NORMAL if idx > 0 else tk.DISABLED)
        self.next_btn.config(text="Next" if idx < len(QUESTIONS)-1 else "Finish")

    def prev_question(self):
        if 0 <= self.q_index < len(self.responses):
            self.responses[self.q_index] = self.res_var.get()
        self.show_question(self.q_index - 1)

    def next_question(self):
        if 0 <= self.q_index < len(self.responses):
            self.responses[self.q_index] = self.res_var.get()
        if self.q_index < len(QUESTIONS) - 1:
            self.show_question(self.q_index + 1)
        else:
            self.analyze_mood()
            messagebox.showinfo("Done", "Questionnaire complete. Mood analyzed and music started (if available).")

    def analyze_mood_manual(self):
        self.analyze_mood()

    def analyze_mood(self):
        if 0 <= self.q_index < len(self.responses):
            self.responses[self.q_index] = self.res_var.get()
        raw = self.responses[:]
        if len(raw) >= 4:
            raw[0] = 6 - raw[0]
            raw[3] = 6 - raw[3]
        avg = sum(raw) / len(raw)
        if avg <= 2.0: mood="Very Sad"
        elif avg <=3.0: mood="Anxious"
        elif avg <=3.8: mood="Neutral"
        elif avg <=4.3: mood="Calm"
        elif avg <=4.7: mood="Focused"
        else: mood="Energetic"
        self.current_mood = mood
        self.mood_var.set(f"Mood: {mood} (avg {avg:.2f})")
        color_map = {
            "Very Sad": "#7a9cc6", "Anxious": "#8ab6d6", "Neutral": "#6b90b6",
            "Calm": "#4ba3c7", "Energetic": "#2b9bd6", "Focused": "#2f7a9e"
        }
        self.line.set_color(color_map.get(mood, COL_DOPA_HIGH))
        lang = self.lang_var.get()
        songs = get_songs_for_mood_and_language(mood, lang)
        if not songs:
            messagebox.showinfo("No Songs", f"No songs stored for mood: {mood} & language: {lang}")
        else:
            self.music.set_playlist(songs)
            self.music.start_playing()
        if not self.sim_running:
            self.start_sim()
        else:
            self.cur_dopa = BASE_DOPAMINE
            self.cur_time = 0
            self.dopa_vals.clear()
            self.time_vals.clear()

    def add_song_dialog(self):
        file = filedialog.askopenfilename(filetypes=[("Audio Files", "*.mp3 *.wav *.ogg")])
        if not file: return
        win = tk.Toplevel(self.root)
        win.title("Add Song to Database")
        win.geometry("360x260")
        win.configure(bg=COL_BG)
        tk.Label(win, text="Song Title:", bg=COL_BG, fg=COL_TEXT, font=("Segoe UI",12)).pack(pady=6)
        title_entry = tk.Entry(win, width=45, font=("Segoe UI",10))
        title_entry.pack()
        tk.Label(win, text="Select Mood:", bg=COL_BG, fg=COL_TEXT, font=("Segoe UI",12)).pack(pady=6)
        mood_var = tk.StringVar(value="Neutral")
        ttk.OptionMenu(win, mood_var, "Neutral", *MOODS).pack()
        tk.Label(win, text="Select Language:", bg=COL_BG, fg=COL_TEXT, font=("Segoe UI",12)).pack(pady=6)
        lang_var = tk.StringVar(value="Any")
        ttk.OptionMenu(win, lang_var, "Any", *SUPPORTED_LANGUAGES).pack()
        def save():
            title = title_entry.get().strip() or os.path.basename(file)
            mood = mood_var.get()
            language = lang_var.get()
            try:
                add_song_to_db(title, file, mood, language)
                messagebox.showinfo("Saved", f"Saved '{title}' for mood '{mood}' and language '{language}'")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save song: {e}")
            win.destroy()
        tk.Button(win, text="Save", bg=COL_BTN, command=save, fg=COL_TEXT, font=("Segoe UI",12,"bold")).pack(pady=14)

    # -----------------------------------
    # Dopamine simulation
    # -----------------------------------
    def start_sim(self):
        self.sim_running = True
        self.dopa_vals = []
        self.time_vals = []
        self.cur_time = 0
        self.cur_dopa = BASE_DOPAMINE
        self.root.after(int(TIME_STEP * 1000), self.sim_step)

    def sim_step(self):
        effect = MOOD_EFFECT.get(self.current_mood, 0.0)
        burst = random.uniform(-1.5,2.5) if random.random()<0.05 else 0.0
        noise = random.uniform(-0.8,0.8)
        pull = 0.05 * (BASE_DOPAMINE - self.cur_dopa) * TIME_STEP
        self.cur_dopa += (effect*1.0 + noise + burst)*TIME_STEP + pull
        self.cur_dopa = max(0, min(120,self.cur_dopa))
        self.cur_time += TIME_STEP
        self.dopa_vals.append(self.cur_dopa)
        self.time_vals.append(self.cur_time)
        self.dopa_var.set(f"Dopamine: {self.cur_dopa:.2f}")
        self.line.set_data(self.time_vals, self.dopa_vals)
        x_min = max(0, self.cur_time-MAX_POINTS*TIME_STEP)
        self.ax.set_xlim(x_min, max(10, self.cur_time))
        y_min = min(self.dopa_vals)-8
        y_max = max(self.dopa_vals)+8
        if y_max-y_min<20: mid=(y_max+y_min)/2; y_min=mid-10; y_max=mid+10
        self.ax.set_ylim(y_min,y_max)
        self.canvas.draw_idle()
        if self.sim_running: self.root.after(int(TIME_STEP*1000), self.sim_step)

    # -----------------------------------
    # Stop music
    # -----------------------------------
    def stop_music(self):
        try: pygame.mixer.music.stop()
        except Exception: pass
        self.music.playing = False

# ============================================================
#  MAIN
# ============================================================
def main():
    root = tk.Tk()
    root.iconbitmap("blue_aura_icon.ico")
    app = BlueAuraApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
