# Design Guidelines for Dope Wellness App

## Design Approach
**Selected Approach:** Custom glassmorphism aesthetic with calm design system principles inspired by Headspace and Calm apps, focusing on emotional wellness and therapeutic UX.

**Core Principle:** Create a serene, therapy-companion experience that feels gentle, non-judgmental, and supportive through visual softness and intentional spacing.

## Color Palette
- **Primary Background:** Soft pastel blue (#e3f2fd to #f0f8ff range)
- **Glassmorphic Panels:** Semi-transparent white/blue overlays with frosted glass effect (background: rgba(255, 255, 255, 0.25), backdrop-filter: blur(12px))
- **Accent Blues:** Range from baby blue (#bbdefb) to sky blue (#90caf9)
- **Text:** Deep navy-grey (#1a334a) for readability on light backgrounds
- **Mood Colors:** Happy (yellow-green), Sad (muted blue), Stressed (orange-red), Angry (deep red), Tired (purple-grey)

## Typography
- **Primary Font:** Inter or Plus Jakarta Sans (rounded, modern, calming)
- **Headings:** Font weights 600-700, sizes from text-4xl (dashboard) to text-lg (section headers)
- **Body Text:** Font weight 400-500, text-base to text-sm
- **Mood Labels:** Font weight 600, text-sm, uppercase tracking

## Layout System
**Spacing Units:** Tailwind spacing of 4, 6, 8, 12, 16, 24 (p-4, gap-6, mb-8, py-12, etc.)

**Container Strategy:**
- Max-width of 1400px for dashboard
- Sections use max-w-7xl with generous padding
- Cards and panels use rounded-2xl to rounded-3xl for soft appearance

## Component Library

### Glassmorphic Panels
- White/translucent background (bg-white/30 to bg-white/40)
- Backdrop blur (backdrop-blur-lg to backdrop-blur-xl)
- Subtle border: border border-white/40
- Soft shadows: shadow-xl with blue tint
- Generous internal padding: p-6 to p-8

### Mood Selection Buttons
- Large circular or rounded-square buttons (w-20 h-20 or similar)
- Each mood has distinct icon and color
- Idle state: Glassmorphic with subtle color hint
- Selected state: Filled with mood color, scale up slightly
- Layout: Grid of 5 buttons (grid-cols-5 gap-4 on desktop, grid-cols-2 gap-3 on mobile with Tired centered)

### Music Player
- Compact horizontal bar or card design
- Shows track title, play/pause/skip controls
- Progress bar with smooth animation
- Volume control optional
- Glassmorphic container with controls arranged horizontally

### Dopamine Progress Visualization
- Horizontal progress bar (h-4 to h-6, rounded-full) or radial gauge
- Gradient fill that changes color based on mood/level
- Percentage or level indicator (0-100 scale)
- Smooth animated transitions when level changes
- Labels showing "Low," "Balanced," "Elevated" states

### Daily Mood History
- Calendar grid view or timeline cards
- Past 7-14 days visible
- Each day shows small mood icon/color
- Click to expand details
- Subtle glassmorphic cards for each entry

### Language Selector
- Dropdown menu (top-right of dashboard)
- Flag icons + language names
- Languages: English, Spanish, French, German, Japanese
- Smooth transition on language change

### Question Form
- Single-question card approach with soft shadows
- Large text input or scale selector (1-5 rating)
- "How do you feel today?" as primary prompt
- Submit button with calming animation
- Thank you confirmation with smooth fade

## Dashboard Layout

**Hero Section (Above Fold):**
- Greeting with user name (if available): "Welcome back, [Name]"
- Current mood display with large icon
- Dopamine level visualization prominently featured
- Quick mood check-in CTA

**Main Dashboard Grid (Below Fold):**
- 2-column layout on desktop (lg:grid-cols-2), single column on mobile
- Left column: Mood selector, Question form
- Right column: Music player, Daily history preview
- All within glassmorphic cards with consistent spacing (gap-6)

**Future Features Section:**
- 3-column grid (lg:grid-cols-3)
- Placeholder cards for: Breathing Exercises (with lung icon), Journaling (pen icon), Sleep Tracker (moon icon)
- Each with "Coming Soon" label
- Subtle grayscale treatment or lower opacity to indicate inactive state

## Animations
**Use Sparingly:**
- Smooth fade-ins for panel appearances (transition-opacity duration-300)
- Scale transforms on mood button selection (hover:scale-105, active state: scale-110)
- Progress bar fill animations (transition-all duration-500 ease-out)
- Gentle floating/breathing animation on main hero elements (optional)

## Images
**Hero Background (Optional):**
- Soft, abstract gradient overlay or subtle nature scene (clouds, calm water)
- Low opacity (20-30%) to maintain text readability
- Blurred effect to support glassmorphism

**Mood Icons:**
- Custom or library icons (Heroicons recommended) for each mood state
- Consistent style across all icons
- Size: w-8 h-8 to w-12 h-12 depending on context

**No large hero image required** - focus on clean glassmorphic interface with soft gradients.

## Accessibility
- All interactive elements have min-height of 44px (touch-friendly)
- Color contrast meets WCAG AA standards despite soft palette
- Form inputs have clear labels and focus states
- Keyboard navigation supported throughout

## Responsive Behavior
- Mobile (base): Single column, stacked components, mood buttons in 2-col grid
- Tablet (md): 2-column dashboard, larger touch targets
- Desktop (lg): Full multi-column layout, optimal spacing, larger glassmorphic panels