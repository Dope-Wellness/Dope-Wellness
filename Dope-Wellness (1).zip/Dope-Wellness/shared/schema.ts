import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export * from "./models/auth";

export type MoodType = "happy" | "sad" | "stressed" | "angry" | "tired";

export const moodEntries = pgTable("mood_entries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id"),
  mood: text("mood").notNull().$type<MoodType>(),
  note: text("note"),
  dopamineLevel: integer("dopamine_level").notNull().default(50),
  date: date("date").notNull().default(sql`CURRENT_DATE`),
  createdAt: timestamp("created_at").notNull().default(sql`NOW()`),
});

export const insertMoodEntrySchema = createInsertSchema(moodEntries).omit({
  id: true,
  createdAt: true,
});

export type InsertMoodEntry = z.infer<typeof insertMoodEntrySchema>;
export type MoodEntry = typeof moodEntries.$inferSelect;

export const moodConfig = {
  happy: {
    label: "Happy",
    color: "#4ade80",
    dopamineBoost: 85,
  },
  sad: {
    label: "Sad",
    color: "#60a5fa",
    dopamineBoost: 30,
  },
  stressed: {
    label: "Stressed",
    color: "#fb923c",
    dopamineBoost: 40,
  },
  angry: {
    label: "Angry",
    color: "#f87171",
    dopamineBoost: 35,
  },
  tired: {
    label: "Tired",
    color: "#a78bfa",
    dopamineBoost: 25,
  },
} as const;
