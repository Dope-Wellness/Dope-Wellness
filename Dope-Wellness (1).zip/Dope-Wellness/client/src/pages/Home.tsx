import { useState, useCallback } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Header } from "@/components/Header";
import { CurrentMoodDisplay } from "@/components/CurrentMoodDisplay";
import { MoodSelector } from "@/components/MoodSelector";
import { MoodCheckInForm } from "@/components/MoodCheckInForm";
import { DopamineVisualization } from "@/components/DopamineVisualization";
import { MusicPlayer } from "@/components/MusicPlayer";
import { MoodHistory } from "@/components/MoodHistory";
import { Recommendations } from "@/components/Recommendations";
import { FutureFeatures } from "@/components/FutureFeatures";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { MoodEntry, MoodType, InsertMoodEntry } from "@shared/schema";
import { moodConfig } from "@shared/schema";

export default function Home() {
  const { toast } = useToast();
  const [selectedMood, setSelectedMood] = useState<MoodType | null>(null);
  const [currentNote, setCurrentNote] = useState<string>("");

  const { data: moodEntries = [], isLoading: isLoadingHistory } = useQuery<MoodEntry[]>({
    queryKey: ["/api/mood-entries"],
  });

  const createMoodEntry = useMutation({
    mutationFn: async (entry: InsertMoodEntry) => {
      const response = await apiRequest("POST", "/api/mood-entries", entry);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/mood-entries"] });
      toast({
        title: "Mood saved!",
        description: "Your mood has been recorded.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save your mood. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleMoodSelect = useCallback((mood: MoodType) => {
    setSelectedMood(mood);
    const dopamineLevel = moodConfig[mood].dopamineBoost;

    createMoodEntry.mutate({
      mood,
      note: currentNote || null,
      dopamineLevel,
      date: new Date().toISOString().split("T")[0],
    });

    setCurrentNote("");
  }, [currentNote, createMoodEntry]);

  const handleNoteSubmit = useCallback((note: string) => {
    setCurrentNote(note);
    if (selectedMood) {
      const dopamineLevel = moodConfig[selectedMood].dopamineBoost;
      createMoodEntry.mutate({
        mood: selectedMood,
        note,
        dopamineLevel,
        date: new Date().toISOString().split("T")[0],
      });
    }
  }, [selectedMood, createMoodEntry]);

  const currentDopamine = selectedMood
    ? moodConfig[selectedMood].dopamineBoost
    : moodEntries[0]?.dopamineLevel || 50;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-sky-50 to-indigo-100 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900 transition-colors duration-500">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-0 w-96 h-96 bg-blue-200/30 dark:bg-blue-900/20 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-purple-200/30 dark:bg-purple-900/20 rounded-full blur-3xl animate-float" style={{ animationDelay: "-2s" }} />
        <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-sky-200/30 dark:bg-sky-900/20 rounded-full blur-3xl animate-float" style={{ animationDelay: "-1s" }} />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 py-6">
        <Header />

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="mb-6"
        >
          <CurrentMoodDisplay
            mood={selectedMood || (moodEntries[0]?.mood as MoodType) || null}
          />
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="space-y-6"
          >
            <MoodSelector
              selectedMood={selectedMood}
              onSelectMood={handleMoodSelect}
            />
            <MoodCheckInForm
              onSubmit={handleNoteSubmit}
              isSubmitting={createMoodEntry.isPending}
            />
            <Recommendations mood={selectedMood} />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="space-y-6"
          >
            <DopamineVisualization
              level={currentDopamine}
              mood={selectedMood}
            />
            <MusicPlayer />
            <MoodHistory
              entries={moodEntries}
              isLoading={isLoadingHistory}
            />
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <FutureFeatures />
        </motion.div>

        <motion.footer
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-center py-8 mt-8"
        >
          <p className="text-sm text-muted-foreground">
            Made with care for your wellness
          </p>
        </motion.footer>
      </div>
    </div>
  );
}
