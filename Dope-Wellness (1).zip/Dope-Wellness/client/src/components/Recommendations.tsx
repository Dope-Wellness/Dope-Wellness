import { motion } from "framer-motion";
import { Heart, Music, Footprints, Droplets, Lightbulb } from "lucide-react";
import { useLanguage } from "@/lib/LanguageContext";
import type { MoodType } from "@shared/schema";

interface RecommendationsProps {
  mood: MoodType | null;
}

const recommendations = [
  { icon: Heart, key: "takeBreath" },
  { icon: Music, key: "listenMusic" },
  { icon: Footprints, key: "goForWalk" },
  { icon: Droplets, key: "drinkWater" },
];

export function Recommendations({ mood }: RecommendationsProps) {
  const { t } = useLanguage();

  return (
    <div className="glass-panel rounded-2xl p-6">
      <div className="flex items-center gap-2 mb-4">
        <Lightbulb className="w-5 h-5 text-amber-500" />
        <h3 className="text-lg font-semibold text-foreground" data-testid="text-recommendations-title">
          {t("recommendations")}
        </h3>
      </div>

      <div className="space-y-3">
        {recommendations.map((rec, index) => {
          const Icon = rec.icon;
          return (
            <motion.div
              key={rec.key}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="flex items-center gap-3 p-3 rounded-xl bg-white/30 dark:bg-slate-800/30 hover-elevate"
              data-testid={`card-recommendation-${index}`}
            >
              <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                <Icon className="w-4 h-4 text-primary" />
              </div>
              <span className="text-sm text-foreground">{t(rec.key)}</span>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
