import { motion } from "framer-motion";
import { Activity } from "lucide-react";
import { useLanguage } from "@/lib/LanguageContext";

interface DopamineVisualizationProps {
  level: number;
  mood: string | null;
}

export function DopamineVisualization({ level, mood }: DopamineVisualizationProps) {
  const { t } = useLanguage();

  const getGradient = (level: number) => {
    if (level < 35) {
      return "from-blue-400 to-blue-600";
    } else if (level < 65) {
      return "from-emerald-400 to-teal-500";
    } else {
      return "from-amber-400 to-orange-500";
    }
  };

  const getStatus = (level: number) => {
    if (level < 35) return t("low");
    if (level < 65) return t("balanced");
    return t("elevated");
  };

  const getStatusColor = (level: number) => {
    if (level < 35) return "text-blue-500 dark:text-blue-400";
    if (level < 65) return "text-emerald-500 dark:text-emerald-400";
    return "text-amber-500 dark:text-amber-400";
  };

  return (
    <div className="glass-panel rounded-2xl p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Activity className="w-5 h-5 text-primary" />
          <h3 className="text-lg font-semibold text-foreground" data-testid="text-dopamine-title">
            {t("dopamineLevel")}
          </h3>
        </div>
        <span className={`text-sm font-medium ${getStatusColor(level)}`} data-testid="text-dopamine-status">
          {getStatus(level)}
        </span>
      </div>

      <div className="relative">
        <div className="h-6 bg-secondary/50 rounded-full overflow-hidden">
          <motion.div
            className={`h-full bg-gradient-to-r ${getGradient(level)} rounded-full`}
            initial={{ width: 0 }}
            animate={{ width: `${level}%` }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          />
        </div>

        <motion.div
          className="absolute top-1/2 -translate-y-1/2 flex items-center justify-center"
          initial={{ left: "0%" }}
          animate={{ left: `${Math.min(level, 95)}%` }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <motion.div
            className={`w-8 h-8 rounded-full bg-gradient-to-r ${getGradient(level)} shadow-lg flex items-center justify-center`}
            animate={{ scale: [1, 1.1, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <span className="text-xs font-bold text-white" data-testid="text-dopamine-level">
              {level}
            </span>
          </motion.div>
        </motion.div>
      </div>

      <div className="flex justify-between mt-3 text-xs text-muted-foreground">
        <span>0</span>
        <span>25</span>
        <span>50</span>
        <span>75</span>
        <span>100</span>
      </div>

      <div className="mt-4 pt-4 border-t border-white/20 dark:border-slate-700/30">
        <div className="grid grid-cols-3 gap-2">
          <div className="text-center p-2 rounded-lg bg-blue-50/50 dark:bg-blue-900/20">
            <div className="w-3 h-3 rounded-full bg-blue-400 mx-auto mb-1" />
            <span className="text-xs text-muted-foreground">{t("low")}</span>
          </div>
          <div className="text-center p-2 rounded-lg bg-emerald-50/50 dark:bg-emerald-900/20">
            <div className="w-3 h-3 rounded-full bg-emerald-400 mx-auto mb-1" />
            <span className="text-xs text-muted-foreground">{t("balanced")}</span>
          </div>
          <div className="text-center p-2 rounded-lg bg-amber-50/50 dark:bg-amber-900/20">
            <div className="w-3 h-3 rounded-full bg-amber-400 mx-auto mb-1" />
            <span className="text-xs text-muted-foreground">{t("elevated")}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
