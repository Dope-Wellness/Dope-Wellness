import { motion } from "framer-motion";
import { Wind, BookOpen, Moon } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useLanguage } from "@/lib/LanguageContext";

interface FeatureCardProps {
  icon: typeof Wind;
  title: string;
  description: string;
  delay: number;
}

function FeatureCard({ icon: Icon, title, description, delay }: FeatureCardProps) {
  const { t } = useLanguage();

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className="glass-panel rounded-2xl p-6 relative overflow-hidden group"
    >
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

      <div className="relative">
        <div className="flex items-start justify-between mb-4">
          <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
            <Icon className="w-6 h-6 text-primary" />
          </div>
          <Badge variant="secondary" className="text-xs opacity-70">
            {t("comingSoon")}
          </Badge>
        </div>

        <h4 className="text-base font-semibold text-foreground mb-2">{title}</h4>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
    </motion.div>
  );
}

export function FutureFeatures() {
  const { t } = useLanguage();

  const features = [
    {
      icon: Wind,
      titleKey: "breathingExercises",
      descKey: "breathingDesc",
    },
    {
      icon: BookOpen,
      titleKey: "journaling",
      descKey: "journalingDesc",
    },
    {
      icon: Moon,
      titleKey: "sleepTracker",
      descKey: "sleepDesc",
    },
  ];

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-foreground" data-testid="text-future-features-title">
        {t("comingSoon")}
      </h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {features.map((feature, index) => (
          <FeatureCard
            key={feature.titleKey}
            icon={feature.icon}
            title={t(feature.titleKey)}
            description={t(feature.descKey)}
            delay={index * 0.1}
          />
        ))}
      </div>
    </div>
  );
}
