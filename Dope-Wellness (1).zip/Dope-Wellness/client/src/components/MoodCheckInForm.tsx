import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Send, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useLanguage } from "@/lib/LanguageContext";

interface MoodCheckInFormProps {
  onSubmit: (note: string) => void;
  isSubmitting?: boolean;
}

export function MoodCheckInForm({ onSubmit, isSubmitting }: MoodCheckInFormProps) {
  const { t } = useLanguage();
  const [note, setNote] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (note.trim()) {
      onSubmit(note);
      setSubmitted(true);
      setTimeout(() => {
        setSubmitted(false);
        setNote("");
      }, 2000);
    }
  };

  return (
    <div className="glass-panel rounded-2xl p-6">
      <h3 className="text-lg font-semibold text-foreground mb-4" data-testid="text-how-are-you">
        {t("howAreYou")}
      </h3>
      <form onSubmit={handleSubmit} className="space-y-4">
        <AnimatePresence mode="wait">
          {!submitted ? (
            <motion.div
              key="form"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-4"
            >
              <Textarea
                data-testid="input-feeling-note"
                placeholder={t("shareFeeling")}
                value={note}
                onChange={(e) => setNote(e.target.value)}
                className="min-h-[100px] resize-none bg-white/50 dark:bg-slate-800/50 border-white/30 dark:border-slate-700/50 focus:border-primary/50 transition-colors"
              />
              <Button
                type="submit"
                data-testid="button-submit-feeling"
                className="w-full gap-2"
                disabled={!note.trim() || isSubmitting}
              >
                <Send className="w-4 h-4" />
                {t("submit")}
              </Button>
            </motion.div>
          ) : (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="flex flex-col items-center justify-center py-8 gap-3"
            >
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 200 }}
                className="w-16 h-16 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center"
              >
                <Check className="w-8 h-8 text-green-600 dark:text-green-400" />
              </motion.div>
              <p className="text-lg font-medium text-foreground" data-testid="text-thank-you">
                {t("thankYou")}
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </form>
    </div>
  );
}
