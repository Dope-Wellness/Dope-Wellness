import { Globe } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useLanguage, languageNames, type Language } from "@/lib/LanguageContext";

const languageCodes: Record<Language, string> = {
  en: "EN",
  es: "ES",
  fr: "FR",
  de: "DE",
  ja: "JA",
};

export function LanguageSelector() {
  const { language, setLanguage } = useLanguage();

  return (
    <Select value={language} onValueChange={(val) => setLanguage(val as Language)}>
      <SelectTrigger
        className="w-[140px] glass-panel border-white/30 dark:border-slate-700/50"
        data-testid="select-language"
      >
        <div className="flex items-center gap-2">
          <Globe className="w-4 h-4 text-muted-foreground" />
          <SelectValue />
        </div>
      </SelectTrigger>
      <SelectContent>
        {(Object.keys(languageNames) as Language[]).map((lang) => (
          <SelectItem key={lang} value={lang} data-testid={`option-language-${lang}`}>
            <div className="flex items-center gap-2">
              <span className="text-xs font-medium text-muted-foreground bg-secondary px-1.5 py-0.5 rounded">
                {languageCodes[lang]}
              </span>
              <span>{languageNames[lang]}</span>
            </div>
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
