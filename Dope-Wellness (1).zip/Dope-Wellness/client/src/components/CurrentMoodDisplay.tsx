import { motion } from "framer-motion";
import { Smile, Frown, Zap, Flame, Battery, Sparkles } from "lucide-react";
import { useLanguage } from "@/lib/LanguageContext";
import type { MoodType } from "@shared/schema";

interface CurrentMoodDisplayProps {
  mood: MoodType | null;
  userName?: string;
}

const moodIcons: Record<MoodType, typeof Smile> = {
  happy: Smile,
  sad: Frown,
  stressed: Zap,
  angry: Flame,
  tired: Battery,
};

const moodGradients: Record<MoodType, string> = {
  happy: "from-green-400 to-emerald-500",
  sad: "from-blue-400 to-indigo-500",
  stressed: "from-orange-400 to-amber-500",
  angry: "from-red-400 to-rose-500",
  tired: "from-purple-400 to-violet-500",
};

export function CurrentMoodDisplay({ mood, userName }: CurrentMoodDisplayProps) {
  const { t } = useLanguage();

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="glass-panel-solid rounded-2xl p-6 md:p-8"
    >
      <div className="flex flex-col md:flex-row items-center gap-6">
        <motion.div
          animate={mood ? { scale: [1, 1.05, 1] } : {}}
          transition={{ duration: 2, repeat: Infinity }}
          className={`w-24 h-24 md:w-28 md:h-28 rounded-full flex items-center justify-center ${
            mood
              ? `bg-gradient-to-br ${moodGradients[mood]} animate-pulse-glow`
              : "bg-gradient-to-br from-primary/30 to-primary/50"
          }`}
        >
          {mood ? (
            (() => {
              const Icon = moodIcons[mood];
              return <Icon className="w-12 h-12 md:w-14 md:h-14 text-white" />;
            })()
          ) : (
            <Sparkles className="w-12 h-12 md:w-14 md:h-14 text-white/70" />
          )}
        </motion.div>

        <div className="text-center md:text-left flex-1">
          <motion.h2
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-2xl md:text-3xl font-bold text-foreground mb-2"
            data-testid="text-welcome"
          >
            {t("welcome")}{userName ? `, ${userName}` : ""}
          </motion.h2>

          {mood ? (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              <p className="text-muted-foreground mb-1">{t("currentMood")}</p>
              <p className="text-xl font-semibold text-foreground" data-testid="text-current-mood">
                {t(mood)}
              </p>
            </motion.div>
          ) : (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="text-muted-foreground"
              data-testid="text-how-are-you-prompt"
            >
              {t("howAreYou")}
            </motion.p>
          )}
        </div>
      </div>
    </motion.div>
  );
}
