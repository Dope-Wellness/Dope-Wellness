import { useState, useRef, useEffect, useCallback } from "react";
import { motion } from "framer-motion";
import { Play, Pause, SkipForward, SkipBack, Volume2, VolumeX, Music, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { useLanguage } from "@/lib/LanguageContext";

interface Track {
  id: number;
  title: string;
  artist: string;
  duration: number;
  url: string;
}

const relaxingTracks: Track[] = [
  {
    id: 1,
    title: "Ocean Waves",
    artist: "Nature Sounds",
    duration: 180,
    url: "https://assets.mixkit.co/active_storage/sfx/2515/2515-preview.mp3",
  },
  {
    id: 2,
    title: "Gentle Rain",
    artist: "Ambient Sleep",
    duration: 240,
    url: "https://assets.mixkit.co/active_storage/sfx/2516/2516-preview.mp3",
  },
  {
    id: 3,
    title: "Forest Birds",
    artist: "Nature Therapy",
    duration: 200,
    url: "https://assets.mixkit.co/active_storage/sfx/2469/2469-preview.mp3",
  },
];

export function MusicPlayer() {
  const { t } = useLanguage();
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [hasError, setHasError] = useState(false);
  const [currentTrackIndex, setCurrentTrackIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const [volume, setVolume] = useState(70);
  const [isMuted, setIsMuted] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const currentTrack = relaxingTracks[currentTrackIndex];

  const nextTrack = useCallback(() => {
    setCurrentTrackIndex((prev) => (prev + 1) % relaxingTracks.length);
    setProgress(0);
    setHasError(false);
  }, []);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) {
      audioRef.current = new Audio();
    }
    
    const currentAudio = audioRef.current;
    currentAudio.src = currentTrack.url;
    currentAudio.volume = isMuted ? 0 : volume / 100;

    const handleTimeUpdate = () => {
      if (currentAudio) {
        const prog = (currentAudio.currentTime / currentAudio.duration) * 100;
        setProgress(isNaN(prog) ? 0 : prog);
      }
    };

    const handleEnded = () => {
      nextTrack();
      if (isPlaying) {
        setTimeout(() => currentAudio?.play().catch(() => setHasError(true)), 100);
      }
    };

    const handleCanPlay = () => {
      setIsLoading(false);
      setHasError(false);
    };

    const handleError = () => {
      setIsLoading(false);
      setHasError(true);
      setIsPlaying(false);
    };

    const handleWaiting = () => {
      setIsLoading(true);
    };

    currentAudio.addEventListener("timeupdate", handleTimeUpdate);
    currentAudio.addEventListener("ended", handleEnded);
    currentAudio.addEventListener("canplay", handleCanPlay);
    currentAudio.addEventListener("error", handleError);
    currentAudio.addEventListener("waiting", handleWaiting);

    return () => {
      currentAudio.removeEventListener("timeupdate", handleTimeUpdate);
      currentAudio.removeEventListener("ended", handleEnded);
      currentAudio.removeEventListener("canplay", handleCanPlay);
      currentAudio.removeEventListener("error", handleError);
      currentAudio.removeEventListener("waiting", handleWaiting);
      currentAudio.pause();
    };
  }, [currentTrackIndex, isPlaying, nextTrack, isMuted, volume]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = isMuted ? 0 : volume / 100;
    }
  }, [volume, isMuted]);

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
        setIsPlaying(false);
      } else {
        setIsLoading(true);
        audioRef.current.play()
          .then(() => {
            setIsPlaying(true);
            setIsLoading(false);
          })
          .catch(() => {
            setHasError(true);
            setIsLoading(false);
          });
      }
    }
  };

  const handleNextTrack = () => {
    nextTrack();
    if (isPlaying && audioRef.current) {
      setTimeout(() => {
        audioRef.current?.play().catch(() => setHasError(true));
      }, 100);
    }
  };

  const prevTrack = () => {
    setCurrentTrackIndex((prev) => (prev - 1 + relaxingTracks.length) % relaxingTracks.length);
    setProgress(0);
    setHasError(false);
    if (isPlaying && audioRef.current) {
      setTimeout(() => {
        audioRef.current?.play().catch(() => setHasError(true));
      }, 100);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  return (
    <div className="glass-panel rounded-2xl p-6">
      <div className="flex items-center gap-2 mb-4">
        <Music className="w-5 h-5 text-primary" />
        <h3 className="text-lg font-semibold text-foreground" data-testid="text-music-title">
          {t("relaxingMusic")}
        </h3>
      </div>

      <div className="flex items-center gap-4 mb-4">
        <motion.div
          animate={isPlaying ? { rotate: 360 } : { rotate: 0 }}
          transition={isPlaying ? { duration: 3, repeat: Infinity, ease: "linear" } : {}}
          className="w-16 h-16 rounded-full bg-gradient-to-br from-primary/30 to-primary/60 flex items-center justify-center flex-shrink-0"
        >
          <Music className="w-8 h-8 text-primary-foreground" />
        </motion.div>
        <div className="flex-1 min-w-0">
          <p className="font-medium text-foreground truncate" data-testid="text-track-title">
            {currentTrack.title}
          </p>
          <p className="text-sm text-muted-foreground truncate" data-testid="text-track-artist">
            {currentTrack.artist}
          </p>
        </div>
      </div>

      <div className="space-y-2 mb-4">
        <div className="relative h-2 bg-secondary rounded-full overflow-hidden">
          <motion.div
            className="absolute left-0 top-0 h-full bg-primary rounded-full"
            style={{ width: `${progress}%` }}
            transition={{ duration: 0.1 }}
          />
        </div>
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>{formatTime((progress / 100) * currentTrack.duration)}</span>
          <span>{formatTime(currentTrack.duration)}</span>
        </div>
      </div>

      {hasError && (
        <div className="mb-4 p-2 bg-destructive/10 rounded-lg text-center">
          <p className="text-sm text-destructive">Unable to load track. Try another.</p>
        </div>
      )}

      <div className="flex items-center justify-center gap-2">
        <Button
          size="icon"
          variant="ghost"
          onClick={prevTrack}
          disabled={isLoading}
          data-testid="button-prev-track"
        >
          <SkipBack className="w-5 h-5" />
        </Button>
        <Button
          size="icon"
          onClick={togglePlay}
          className="w-12 h-12"
          disabled={isLoading}
          data-testid="button-play-pause"
        >
          {isLoading ? (
            <Loader2 className="w-5 h-5 animate-spin" />
          ) : isPlaying ? (
            <Pause className="w-5 h-5" />
          ) : (
            <Play className="w-5 h-5 ml-0.5" />
          )}
        </Button>
        <Button
          size="icon"
          variant="ghost"
          onClick={handleNextTrack}
          disabled={isLoading}
          data-testid="button-next-track"
        >
          <SkipForward className="w-5 h-5" />
        </Button>
      </div>

      <div className="flex items-center gap-3 mt-4 pt-4 border-t border-white/20 dark:border-slate-700/30">
        <Button
          size="icon"
          variant="ghost"
          onClick={() => setIsMuted(!isMuted)}
          data-testid="button-mute"
        >
          {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
        </Button>
        <Slider
          data-testid="slider-volume"
          value={[isMuted ? 0 : volume]}
          onValueChange={([val]) => {
            setVolume(val);
            if (isMuted) setIsMuted(false);
          }}
          max={100}
          step={1}
          className="flex-1"
        />
      </div>
    </div>
  );
}
