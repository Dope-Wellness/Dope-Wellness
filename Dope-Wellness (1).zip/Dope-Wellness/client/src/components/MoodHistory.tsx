import { motion } from "framer-motion";
import { Calendar, Smile, Frown, Zap, Flame, Battery } from "lucide-react";
import { useLanguage } from "@/lib/LanguageContext";
import type { MoodEntry, MoodType } from "@shared/schema";

interface MoodHistoryProps {
  entries: MoodEntry[];
  isLoading?: boolean;
}

const moodIcons: Record<MoodType, typeof Smile> = {
  happy: Smile,
  sad: Frown,
  stressed: Zap,
  angry: Flame,
  tired: Battery,
};

const moodBgColors: Record<MoodType, string> = {
  happy: "bg-green-100 dark:bg-green-900/40",
  sad: "bg-blue-100 dark:bg-blue-900/40",
  stressed: "bg-orange-100 dark:bg-orange-900/40",
  angry: "bg-red-100 dark:bg-red-900/40",
  tired: "bg-purple-100 dark:bg-purple-900/40",
};

const moodIconColors: Record<MoodType, string> = {
  happy: "text-green-600 dark:text-green-400",
  sad: "text-blue-600 dark:text-blue-400",
  stressed: "text-orange-600 dark:text-orange-400",
  angry: "text-red-600 dark:text-red-400",
  tired: "text-purple-600 dark:text-purple-400",
};

function formatDate(dateStr: string, t: (key: string) => string): string {
  const date = new Date(dateStr);
  const today = new Date();
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);

  if (date.toDateString() === today.toDateString()) {
    return t("today");
  }
  if (date.toDateString() === yesterday.toDateString()) {
    return t("yesterday");
  }

  return date.toLocaleDateString(undefined, {
    weekday: "short",
    month: "short",
    day: "numeric",
  });
}

export function MoodHistory({ entries, isLoading }: MoodHistoryProps) {
  const { t } = useLanguage();

  return (
    <div className="glass-panel rounded-2xl p-6">
      <div className="flex items-center gap-2 mb-4">
        <Calendar className="w-5 h-5 text-primary" />
        <h3 className="text-lg font-semibold text-foreground" data-testid="text-mood-history-title">
          {t("moodHistory")}
        </h3>
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="animate-pulse flex items-center gap-3 p-3 rounded-xl bg-secondary/30">
              <div className="w-10 h-10 rounded-full bg-secondary" />
              <div className="flex-1 space-y-2">
                <div className="h-4 bg-secondary rounded w-1/3" />
                <div className="h-3 bg-secondary rounded w-1/2" />
              </div>
            </div>
          ))}
        </div>
      ) : entries.length === 0 ? (
        <div className="text-center py-8">
          <Calendar className="w-12 h-12 text-muted-foreground/50 mx-auto mb-3" />
          <p className="text-muted-foreground" data-testid="text-no-history">
            {t("noHistory")}
          </p>
        </div>
      ) : (
        <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1">
          {entries.slice(0, 7).map((entry, index) => {
            const Icon = moodIcons[entry.mood as MoodType];
            const bgColor = moodBgColors[entry.mood as MoodType];
            const iconColor = moodIconColors[entry.mood as MoodType];

            return (
              <motion.div
                key={entry.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`flex items-center gap-3 p-3 rounded-xl ${bgColor}`}
                data-testid={`card-mood-entry-${entry.id}`}
              >
                <div className={`w-10 h-10 rounded-full ${bgColor} flex items-center justify-center`}>
                  <Icon className={`w-5 h-5 ${iconColor}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className={`font-medium ${iconColor}`} data-testid={`text-mood-${entry.id}`}>
                      {t(entry.mood)}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {formatDate(entry.date, t)}
                    </span>
                  </div>
                  {entry.note && (
                    <p className="text-sm text-muted-foreground truncate" data-testid={`text-note-${entry.id}`}>
                      {entry.note}
                    </p>
                  )}
                </div>
                <div className="text-right flex-shrink-0">
                  <div className="text-xs text-muted-foreground">{t("dopamineLevel")}</div>
                  <div className="text-sm font-semibold text-foreground">{entry.dopamineLevel}%</div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
