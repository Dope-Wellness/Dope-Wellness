import { motion } from "framer-motion";
import { Smile, Frown, Zap, Flame, Battery } from "lucide-react";
import { useLanguage } from "@/lib/LanguageContext";
import type { MoodType } from "@shared/schema";

interface MoodSelectorProps {
  selectedMood: MoodType | null;
  onSelectMood: (mood: MoodType) => void;
}

const moodIcons = {
  happy: Smile,
  sad: Frown,
  stressed: Zap,
  angry: Flame,
  tired: Battery,
};

const moodColors = {
  happy: {
    bg: "bg-green-100 dark:bg-green-900/30",
    selected: "bg-green-400 dark:bg-green-500",
    ring: "ring-green-400",
    text: "text-green-700 dark:text-green-300",
  },
  sad: {
    bg: "bg-blue-100 dark:bg-blue-900/30",
    selected: "bg-blue-400 dark:bg-blue-500",
    ring: "ring-blue-400",
    text: "text-blue-700 dark:text-blue-300",
  },
  stressed: {
    bg: "bg-orange-100 dark:bg-orange-900/30",
    selected: "bg-orange-400 dark:bg-orange-500",
    ring: "ring-orange-400",
    text: "text-orange-700 dark:text-orange-300",
  },
  angry: {
    bg: "bg-red-100 dark:bg-red-900/30",
    selected: "bg-red-400 dark:bg-red-500",
    ring: "ring-red-400",
    text: "text-red-700 dark:text-red-300",
  },
  tired: {
    bg: "bg-purple-100 dark:bg-purple-900/30",
    selected: "bg-purple-400 dark:bg-purple-500",
    ring: "ring-purple-400",
    text: "text-purple-700 dark:text-purple-300",
  },
};

export function MoodSelector({ selectedMood, onSelectMood }: MoodSelectorProps) {
  const { t } = useLanguage();
  const moods: MoodType[] = ["happy", "sad", "stressed", "angry", "tired"];

  return (
    <div className="glass-panel rounded-2xl p-6">
      <h3 className="text-lg font-semibold text-foreground mb-4" data-testid="text-select-mood-title">
        {t("selectMood")}
      </h3>
      <div className="grid grid-cols-5 gap-3 md:gap-4">
        {moods.map((mood) => {
          const Icon = moodIcons[mood];
          const colors = moodColors[mood];
          const isSelected = selectedMood === mood;

          return (
            <motion.button
              key={mood}
              data-testid={`button-mood-${mood}`}
              onClick={() => onSelectMood(mood)}
              className={`
                relative flex flex-col items-center justify-center gap-2 p-3 md:p-4 rounded-xl
                transition-all duration-300 overflow-visible
                ${isSelected ? colors.selected : colors.bg}
                ${isSelected ? "ring-2 ring-offset-2 ring-offset-background " + colors.ring : ""}
              `}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              animate={isSelected ? { scale: 1.08 } : { scale: 1 }}
            >
              <Icon
                className={`w-6 h-6 md:w-8 md:h-8 ${isSelected ? "text-white" : colors.text}`}
              />
              <span
                className={`text-xs md:text-sm font-medium ${isSelected ? "text-white" : colors.text}`}
              >
                {t(mood)}
              </span>
              {isSelected && (
                <motion.div
                  layoutId="mood-indicator"
                  className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-2 h-2 rounded-full bg-white"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                />
              )}
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}
