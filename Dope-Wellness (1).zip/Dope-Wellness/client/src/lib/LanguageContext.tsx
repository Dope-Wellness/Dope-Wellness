import { createContext, useContext, useState, useCallback, type ReactNode } from "react";

export type Language = "en" | "es" | "fr" | "de" | "ja";

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations: Record<Language, Record<string, string>> = {
  en: {
    appName: "Dope",
    tagline: "Your Wellness Companion",
    welcome: "Welcome back",
    howAreYou: "How are you feeling today?",
    selectMood: "Select your mood",
    happy: "Happy",
    sad: "Sad",
    stressed: "Stressed",
    angry: "Angry",
    tired: "Tired",
    dopamineLevel: "Dopamine Level",
    low: "Low",
    balanced: "Balanced",
    elevated: "Elevated",
    moodHistory: "Mood History",
    today: "Today",
    yesterday: "Yesterday",
    noHistory: "No mood entries yet. Start tracking!",
    relaxingMusic: "Relaxing Music",
    nowPlaying: "Now Playing",
    recommendations: "Recommendations for you",
    takeBreath: "Take a deep breath",
    listenMusic: "Listen to calming music",
    goForWalk: "Go for a short walk",
    drinkWater: "Drink some water",
    comingSoon: "Coming Soon",
    breathingExercises: "Breathing Exercises",
    journaling: "Journaling",
    sleepTracker: "Sleep Tracker",
    breathingDesc: "Guided breathing for relaxation",
    journalingDesc: "Write your thoughts freely",
    sleepDesc: "Track your sleep patterns",
    shareFeeling: "Share how you're feeling...",
    submit: "Submit",
    thankYou: "Thank you for sharing!",
    currentMood: "Current Mood",
    settings: "Settings",
    language: "Language",
  },
  es: {
    appName: "Dope",
    tagline: "Tu Companero de Bienestar",
    welcome: "Bienvenido de nuevo",
    howAreYou: "Como te sientes hoy?",
    selectMood: "Selecciona tu estado de animo",
    happy: "Feliz",
    sad: "Triste",
    stressed: "Estresado",
    angry: "Enojado",
    tired: "Cansado",
    dopamineLevel: "Nivel de Dopamina",
    low: "Bajo",
    balanced: "Equilibrado",
    elevated: "Elevado",
    moodHistory: "Historial de Animo",
    today: "Hoy",
    yesterday: "Ayer",
    noHistory: "Sin entradas aun. Comienza a registrar!",
    relaxingMusic: "Musica Relajante",
    nowPlaying: "Reproduciendo",
    recommendations: "Recomendaciones para ti",
    takeBreath: "Respira profundamente",
    listenMusic: "Escucha musica relajante",
    goForWalk: "Da un paseo corto",
    drinkWater: "Toma agua",
    comingSoon: "Proximamente",
    breathingExercises: "Ejercicios de Respiracion",
    journaling: "Diario",
    sleepTracker: "Seguimiento del Sueno",
    breathingDesc: "Respiracion guiada para relajarte",
    journalingDesc: "Escribe tus pensamientos",
    sleepDesc: "Rastrea tus patrones de sueno",
    shareFeeling: "Comparte como te sientes...",
    submit: "Enviar",
    thankYou: "Gracias por compartir!",
    currentMood: "Estado Actual",
    settings: "Configuracion",
    language: "Idioma",
  },
  fr: {
    appName: "Dope",
    tagline: "Votre Compagnon Bien-etre",
    welcome: "Bon retour",
    howAreYou: "Comment vous sentez-vous aujourd'hui?",
    selectMood: "Selectionnez votre humeur",
    happy: "Heureux",
    sad: "Triste",
    stressed: "Stresse",
    angry: "En colere",
    tired: "Fatigue",
    dopamineLevel: "Niveau de Dopamine",
    low: "Bas",
    balanced: "Equilibre",
    elevated: "Eleve",
    moodHistory: "Historique d'Humeur",
    today: "Aujourd'hui",
    yesterday: "Hier",
    noHistory: "Pas encore d'entrees. Commencez!",
    relaxingMusic: "Musique Relaxante",
    nowPlaying: "En cours",
    recommendations: "Recommandations pour vous",
    takeBreath: "Respirez profondement",
    listenMusic: "Ecoutez de la musique apaisante",
    goForWalk: "Faites une courte promenade",
    drinkWater: "Buvez de l'eau",
    comingSoon: "Bientot Disponible",
    breathingExercises: "Exercices de Respiration",
    journaling: "Journal",
    sleepTracker: "Suivi du Sommeil",
    breathingDesc: "Respiration guidee pour la relaxation",
    journalingDesc: "Ecrivez vos pensees librement",
    sleepDesc: "Suivez vos habitudes de sommeil",
    shareFeeling: "Partagez ce que vous ressentez...",
    submit: "Envoyer",
    thankYou: "Merci d'avoir partage!",
    currentMood: "Humeur Actuelle",
    settings: "Parametres",
    language: "Langue",
  },
  de: {
    appName: "Dope",
    tagline: "Ihr Wellness-Begleiter",
    welcome: "Willkommen zuruck",
    howAreYou: "Wie fuhlen Sie sich heute?",
    selectMood: "Wahlen Sie Ihre Stimmung",
    happy: "Glucklich",
    sad: "Traurig",
    stressed: "Gestresst",
    angry: "Wutend",
    tired: "Mude",
    dopamineLevel: "Dopamin-Niveau",
    low: "Niedrig",
    balanced: "Ausgeglichen",
    elevated: "Erhöht",
    moodHistory: "Stimmungsverlauf",
    today: "Heute",
    yesterday: "Gestern",
    noHistory: "Noch keine Eintrage. Starten Sie jetzt!",
    relaxingMusic: "Entspannende Musik",
    nowPlaying: "Wird gespielt",
    recommendations: "Empfehlungen fur Sie",
    takeBreath: "Atmen Sie tief durch",
    listenMusic: "Horen Sie beruhigende Musik",
    goForWalk: "Machen Sie einen Spaziergang",
    drinkWater: "Trinken Sie Wasser",
    comingSoon: "Demnachst Verfugbar",
    breathingExercises: "Atemubungen",
    journaling: "Tagebuch",
    sleepTracker: "Schlaf-Tracker",
    breathingDesc: "Gefuhrte Atmung zur Entspannung",
    journalingDesc: "Schreiben Sie Ihre Gedanken",
    sleepDesc: "Verfolgen Sie Ihre Schlafmuster",
    shareFeeling: "Teilen Sie Ihre Gefuhle...",
    submit: "Absenden",
    thankYou: "Danke furs Teilen!",
    currentMood: "Aktuelle Stimmung",
    settings: "Einstellungen",
    language: "Sprache",
  },
  ja: {
    appName: "Dope",
    tagline: "あなたのウェルネスパートナー",
    welcome: "おかえりなさい",
    howAreYou: "今日の気分はいかがですか？",
    selectMood: "気分を選択してください",
    happy: "幸せ",
    sad: "悲しい",
    stressed: "ストレス",
    angry: "怒り",
    tired: "疲れた",
    dopamineLevel: "ドーパミンレベル",
    low: "低い",
    balanced: "バランス",
    elevated: "高い",
    moodHistory: "気分の履歴",
    today: "今日",
    yesterday: "昨日",
    noHistory: "まだ記録がありません。始めましょう！",
    relaxingMusic: "リラックス音楽",
    nowPlaying: "再生中",
    recommendations: "おすすめ",
    takeBreath: "深呼吸をしましょう",
    listenMusic: "癒しの音楽を聴く",
    goForWalk: "散歩に出かける",
    drinkWater: "水を飲む",
    comingSoon: "近日公開",
    breathingExercises: "呼吸エクササイズ",
    journaling: "ジャーナリング",
    sleepTracker: "睡眠トラッカー",
    breathingDesc: "リラックスのための呼吸法",
    journalingDesc: "思いを自由に書く",
    sleepDesc: "睡眠パターンを追跡",
    shareFeeling: "気持ちを共有...",
    submit: "送信",
    thankYou: "共有ありがとうございます！",
    currentMood: "現在の気分",
    settings: "設定",
    language: "言語",
  },
};

const languageNames: Record<Language, string> = {
  en: "English",
  es: "Español",
  fr: "Français",
  de: "Deutsch",
  ja: "日本語",
};

export { languageNames };

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("dope-language");
      if (saved && saved in translations) {
        return saved as Language;
      }
    }
    return "en";
  });

  const setLanguage = useCallback((lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem("dope-language", lang);
  }, []);

  const t = useCallback(
    (key: string) => {
      return translations[language][key] || translations.en[key] || key;
    },
    [language]
  );

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
}
