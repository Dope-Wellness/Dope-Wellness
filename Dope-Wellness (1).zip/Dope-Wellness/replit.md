# Dope Wellness App

## Overview

Dope is a wellness companion web application designed to help users track their emotional well-being, listen to relaxing music, and visualize dopamine levels. The app features a calming, therapy-inspired design with glassmorphism aesthetics, mood tracking, and personalized recommendations. Built as a full-stack TypeScript application with React frontend and Express backend.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight alternative to React Router)
- **State Management**: TanStack React Query for server state, React Context for UI state (theme, language)
- **Styling**: Tailwind CSS with custom glassmorphism design system
- **UI Components**: shadcn/ui component library (Radix UI primitives)
- **Animations**: Framer Motion for smooth transitions and micro-interactions
- **Build Tool**: Vite with path aliases (@/, @shared/, @assets/)

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript (ESM modules)
- **API Design**: RESTful endpoints under /api prefix
- **Development**: tsx for hot reloading, Vite middleware for frontend serving

### Data Storage
- **Database**: PostgreSQL with Drizzle ORM
- **Schema Location**: shared/schema.ts (shared between frontend and backend)
- **Migrations**: drizzle-kit for schema management
- **Validation**: Zod schemas generated from Drizzle tables via drizzle-zod

### Key Data Models
- **Users**: Basic authentication model (id, username, password)
- **MoodEntries**: Mood tracking with mood type, notes, dopamine level, and timestamps
- **MoodTypes**: Enumerated values (happy, sad, stressed, angry, tired) with associated colors and dopamine boost values

### Design System
- **Theme**: Custom glassmorphism with pastel blue palette
- **Dark Mode**: Full dark mode support via ThemeContext
- **Internationalization**: Multi-language support (English, Spanish, French, German, Japanese) via LanguageContext
- **Typography**: Inter/Plus Jakarta Sans for calming aesthetic

### API Structure
- `GET /api/mood-entries` - Fetch all mood entries (limited to 50, ordered by date)
- `GET /api/mood-entries/:id` - Fetch single mood entry
- `POST /api/mood-entries` - Create new mood entry
- `DELETE /api/mood-entries/:id` - Delete mood entry

### Build Configuration
- Development: `npm run dev` runs tsx with Vite middleware
- Production: `npm run build` bundles server with esbuild, client with Vite
- Database: `npm run db:push` pushes schema changes via drizzle-kit

## External Dependencies

### Database
- **PostgreSQL**: Primary database (requires DATABASE_URL environment variable)
- **Connection**: pg Pool with Drizzle ORM wrapper

### UI Libraries
- **Radix UI**: Full suite of accessible primitives (dialog, dropdown, select, etc.)
- **Framer Motion**: Animation library for React
- **Lucide React**: Icon library
- **Embla Carousel**: Carousel component
- **Recharts**: Charting library for data visualization

### Development Tools
- **Vite**: Frontend build tool with HMR
- **drizzle-kit**: Database migration management
- **esbuild**: Server bundling for production
- **Replit plugins**: Dev banner, cartographer, runtime error overlay

### Audio
- Uses external audio URLs (Mixkit assets) for relaxing music player - no audio files stored locally